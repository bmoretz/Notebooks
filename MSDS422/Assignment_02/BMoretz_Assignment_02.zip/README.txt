Assignment_02.ipynb - Jupyter Notebook for the assignment
Term Deposit Participation.pdf - Executive summary to management
cv-results.txt - Model output Results
datasets/bank.csv - data for the research assignment.